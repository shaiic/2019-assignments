import sys
from keras.models import load_model
import argparse
import cv2
import numpy as np
DEFAULT_MODEL = "model/mnist_model.h5"

def main(args=None):
    if args is None:
        args = sys.argv[1:]
    parser = argparse.ArgumentParser()
    parser.add_argument("image_path")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    args = parser.parse_args(args)

    img = cv2.imread(args.image_path,0)
    img = cv2.resize(img,(28,28))
    img = img.reshape(1,img.shape[0], img.shape[1],1)
    img = img.astype('float32')
    img = img / 255

    model = load_model(args.model)

    result = np.argmax(model.predict(img)[0])

    print('待识别的图片:---', args.image_path)
    print('识别结果：------', result)





if __name__ == "__main__":
    main()