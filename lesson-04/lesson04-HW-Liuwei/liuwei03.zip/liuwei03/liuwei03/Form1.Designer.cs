﻿namespace liuwei03
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBoxKTDD = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBoxWSTD = new System.Windows.Forms.PictureBox();
            this.pictureBoxWSCTD = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKTDD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWSTD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWSCTD)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(373, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(415, 426);
            this.textBox1.TabIndex = 5;
            // 
            // pictureBoxKTDD
            // 
            this.pictureBoxKTDD.Location = new System.Drawing.Point(12, 203);
            this.pictureBoxKTDD.Name = "pictureBoxKTDD";
            this.pictureBoxKTDD.Size = new System.Drawing.Size(83, 235);
            this.pictureBoxKTDD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxKTDD.TabIndex = 4;
            this.pictureBoxKTDD.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(76, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(214, 79);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBoxWSTD
            // 
            this.pictureBoxWSTD.Location = new System.Drawing.Point(122, 203);
            this.pictureBoxWSTD.Name = "pictureBoxWSTD";
            this.pictureBoxWSTD.Size = new System.Drawing.Size(83, 235);
            this.pictureBoxWSTD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxWSTD.TabIndex = 6;
            this.pictureBoxWSTD.TabStop = false;
            // 
            // pictureBoxWSCTD
            // 
            this.pictureBoxWSCTD.Location = new System.Drawing.Point(239, 203);
            this.pictureBoxWSCTD.Name = "pictureBoxWSCTD";
            this.pictureBoxWSCTD.Size = new System.Drawing.Size(83, 235);
            this.pictureBoxWSCTD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxWSCTD.TabIndex = 7;
            this.pictureBoxWSCTD.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "客厅顶灯";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "卧室台灯";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "卧室床头灯";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBoxWSCTD);
            this.Controls.Add(this.pictureBoxWSTD);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBoxKTDD);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKTDD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWSTD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWSCTD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBoxKTDD;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBoxWSTD;
        private System.Windows.Forms.PictureBox pictureBoxWSCTD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

